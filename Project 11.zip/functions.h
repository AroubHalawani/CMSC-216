#if !defined(FUNCTIONS_H)
#define FUNCTIONS_H

/* (c) Larry Herman, 2020.  You are allowed to use this code yourself, but
 * not to provide it to anyone else.
 */

int add(int a, int b);

#endif
